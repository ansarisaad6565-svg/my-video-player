package com.example.videoplayer

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

data class Video(val uri: Uri, val name: String, val durationMs: Long, val size: Long)

class MainActivity : AppCompatActivity() {
    private val videos = mutableListOf<Video>()
    private lateinit var adapter: VideoAdapter

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) loadVideos() else showEmpty()
        }

    private val permission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        adapter = VideoAdapter(videos) { v ->
            startActivity(Intent(this, PlayerActivity::class.java).apply {
                putExtra("uri", v.uri.toString())
                putExtra("title", v.name)
            })
        }
        findViewById<RecyclerView>(R.id.list).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = this@MainActivity.adapter
        }
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED)
            loadVideos() else permLauncher.launch(permission)
    }

    private fun showEmpty() {
        findViewById<View>(R.id.empty).visibility = if (videos.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun loadVideos() {
        videos.clear()
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE
        )
        contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                videos.add(
                    Video(
                        ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "Video", c.getLong(2), c.getLong(3)
                    )
                )
            }
        }
        adapter.notifyDataSetChanged()
        showEmpty()
    }
}

class VideoAdapter(private val items: List<Video>, private val onClick: (Video) -> Unit) :
    RecyclerView.Adapter<VideoAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val title: TextView = v.findViewById(R.id.title)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_video, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val v = items[i]
        h.title.text = v.name
        val s = v.durationMs / 1000
        val time = if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
        h.meta.text = "$time  •  ${v.size / (1024 * 1024)} MB"
        Glide.with(h.thumb).load(v.uri).centerCrop().into(h.thumb)
        h.itemView.setOnClickListener { onClick(v) }
    }
}
