package com.example.videoplayer

import android.Manifest
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide

class MainActivity : AppCompatActivity() {
    private val videos = mutableListOf<Video>()
    private val rows = mutableListOf<Row>()
    private lateinit var adapter: RowAdapter
    private lateinit var list: RecyclerView
    private lateinit var tvHeader: TextView
    private var curFolder: Long? = null
    private var curSeries: String? = null
    private var appliedTheme = 0

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
            if (ok) loadVideos() else showEmpty()
        }

    private val permission: String
        get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    override fun onCreate(savedInstanceState: Bundle?) {
        AppTheme.apply(this)
        appliedTheme = AppTheme.index(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvHeader = findViewById(R.id.tvHeader)
        adapter = RowAdapter(rows)
        list = findViewById(R.id.list)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (curSeries != null) {
                    curSeries = null
                    render()
                } else if (curFolder != null) {
                    curFolder = null
                    render()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED)
            loadVideos() else permLauncher.launch(permission)
    }

    override fun onResume() {
        super.onResume()
        if (appliedTheme != AppTheme.index(this)) recreate()
    }

    private fun showEmpty() {
        findViewById<View>(R.id.empty).visibility = if (videos.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun loadVideos() {
        videos.clear()
        val proj = arrayOf(
            MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION, MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.BUCKET_ID, MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        contentResolver.query(
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI, proj, null, null,
            "${MediaStore.Video.Media.DATE_ADDED} DESC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                videos.add(
                    Video(
                        ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id),
                        c.getString(1) ?: "Video", c.getLong(2), c.getLong(3),
                        c.getLong(4), c.getString(5) ?: "Other"
                    )
                )
            }
        }
        render()
    }

    private fun meta(v: Video, prefix: String = ""): String =
        prefix + fmtDuration(v.durationMs) + "  \u2022  " + (v.size / (1024 * 1024)) + " MB"

    private fun render() {
        rows.clear()
        val folder = curFolder
        if (folder == null) {
            tvHeader.text = "My Videos"
            videos.groupBy { it.bucketId }.values
                .sortedBy { it.first().bucket.lowercase() }
                .forEach { vs ->
                    val id = vs.first().bucketId
                    rows.add(Row(vs.first().uri, "\uD83D\uDCC1 " + vs.first().bucket, "${vs.size} videos") {
                        curFolder = id
                        curSeries = null
                        render()
                    })
                }
        } else {
            val fv = videos.filter { it.bucketId == folder }
            val fname = fv.firstOrNull()?.bucket ?: "Folder"
            val content = NameParser.group(fv, fname)
            val sKey = curSeries
            if (sKey == null) {
                tvHeader.text = fname
                content.series.forEach { g ->
                    val seasons = g.eps.mapNotNull { it.ep?.season }.distinct()
                    val m = "${g.eps.size} episodes" +
                        if (seasons.size > 1) "  \u2022  ${seasons.size} seasons" else ""
                    rows.add(Row(g.eps.first().uri, "\uD83D\uDCFA " + g.name, m) {
                        curSeries = g.key
                        render()
                    })
                }
                content.singles.forEach { v ->
                    val t = NameParser.movieTitle(v.name)
                    rows.add(Row(v.uri, t, meta(v)) { play(listOf(v), 0, listOf(t)) })
                }
            } else {
                val g = content.series.firstOrNull { it.key == sKey }
                if (g == null) {
                    curSeries = null
                    render()
                    return
                }
                tvHeader.text = g.name
                val titles = g.eps.map { NameParser.episodeTitle(g.name, it) }
                g.eps.forEachIndexed { i, v ->
                    val e = v.ep
                    val label = if (e != null) "S%02d \u2022 Episode %d".format(e.season, e.episode) else v.name
                    rows.add(Row(v.uri, label, meta(v)) { play(g.eps, i, titles) })
                }
            }
        }
        adapter.notifyDataSetChanged()
        list.scrollToPosition(0)
        showEmpty()
    }

    private fun play(list: List<Video>, index: Int, titles: List<String>) {
        val v = list[index]
        startActivity(Intent(this, PlayerActivity::class.java).apply {
            putExtra("uri", v.uri.toString())
            putExtra("title", titles[index])
            if (list.size > 1) {
                putStringArrayListExtra(Playlist.URIS, ArrayList(list.map { it.uri.toString() }))
                putStringArrayListExtra(Playlist.TITLES, ArrayList(titles))
                putExtra(Playlist.INDEX, index)
            }
        })
    }
}

class Row(val thumb: Uri?, val title: String, val meta: String, val onClick: () -> Unit)

class RowAdapter(private val items: List<Row>) : RecyclerView.Adapter<RowAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val thumb: ImageView = v.findViewById(R.id.thumb)
        val title: TextView = v.findViewById(R.id.title)
        val meta: TextView = v.findViewById(R.id.meta)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_video, p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val r = items[i]
        h.title.text = r.title
        h.meta.text = r.meta
        val t = r.thumb
        if (t != null) Glide.with(h.thumb).load(t).centerCrop().into(h.thumb)
        else h.thumb.setImageDrawable(null)
        h.itemView.setOnClickListener { r.onClick() }
    }
}
