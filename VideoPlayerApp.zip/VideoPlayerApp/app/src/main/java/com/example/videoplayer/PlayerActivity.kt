package com.example.videoplayer

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

class PlayerActivity : AppCompatActivity() {
    // libVLC slave type: 0 = Subtitle
    private val SUBTITLE_SLAVE = 0
    private lateinit var libVLC: LibVLC
    private lateinit var mp: MediaPlayer
    private lateinit var vlcLayout: VLCVideoLayout
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var seekBar: SeekBar
    private lateinit var tvTime: TextView
    private lateinit var tvTotal: TextView
    private lateinit var btnPlay: Button
    private lateinit var btnSpeed: Button
    private lateinit var seekText: TextView
    private lateinit var subText: TextView
    private lateinit var videoUri: Uri

    private var pfd: ParcelFileDescriptor? = null
    private var subFile: File? = null
    private var resumeTime = 0L
    private var dragging = false
    private var firstPlay = true
    private var speedIndex = 0
    private class Cue(val start: Long, val end: Long, val text: String)
    private var extCues: List<Cue>? = null
    private var extName = ""
    private var extActive = false
    private var extOffsetMs = 0L
    private var embOffsetMs = 0L
    private var lastCue: Cue? = null
    private val tick = object : Runnable {
        override fun run() {
            updateExternalSub()
            ui.postDelayed(this, 100)
        }
    }
    private val speeds = floatArrayOf(1f, 1.25f, 1.5f, 2f, 0.75f)
    private val ui = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { showControls(false) }

    private val pickSub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = displayName(uri).replace('/', '_')
            val f = File(cacheDir, name)
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            val ext = name.substringAfterLast('.', "").lowercase()
            if (ext == "ass" || ext == "ssa") {
                subFile = f
                extActive = false
                subText.visibility = View.GONE
                mp.addSlave(SUBTITLE_SLAVE, Uri.fromFile(f), true)
                Toast.makeText(this, "Subtitle loaded: $name", Toast.LENGTH_SHORT).show()
            } else {
                val bytes = f.readBytes()
                var text = String(bytes, Charsets.UTF_8)
                if (text.contains('\uFFFD')) text = String(bytes, Charsets.ISO_8859_1)
                val cues = parseSubs(text.removePrefix("\uFEFF"))
                if (cues.isEmpty()) {
                    Toast.makeText(this, "Ye subtitle file padh nahi payi", Toast.LENGTH_LONG).show()
                } else {
                    extCues = cues
                    extName = name
                    extOffsetMs = 0L
                    extActive = true
                    mp.setSpuTrack(-1)
                    Toast.makeText(this, "Subtitle loaded: $name (${cues.size} lines)", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        videoUri = Uri.parse(intent.getStringExtra("uri"))

        vlcLayout = findViewById(R.id.vlcLayout)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        seekBar = findViewById(R.id.seekBar)
        tvTime = findViewById(R.id.tvTime)
        tvTotal = findViewById(R.id.tvTotal)
        btnPlay = findViewById(R.id.btnPlay)
        btnSpeed = findViewById(R.id.btnSpeed)
        seekText = findViewById(R.id.seekText)
        subText = findViewById(R.id.subText)

        libVLC = LibVLC(this, arrayListOf("--no-drop-late-frames", "--no-skip-frames"))
        mp = MediaPlayer(libVLC)

        mp.setEventListener { ev ->
            val type = ev.type
            val timeMs = ev.timeChanged
            val lenMs = ev.lengthChanged
            runOnUiThread {
                when (type) {
                    MediaPlayer.Event.Playing -> onPlaying()
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> btnPlay.text = "▶"
                    MediaPlayer.Event.LengthChanged -> {
                        seekBar.max = lenMs.toInt()
                        tvTotal.text = fmt(lenMs)
                    }
                    MediaPlayer.Event.TimeChanged -> if (!dragging) {
                        seekBar.progress = timeMs.toInt()
                        tvTime.text = fmt(timeMs)
                    }
                    MediaPlayer.Event.EncounteredError ->
                        Toast.makeText(this, "Video play nahi ho paya", Toast.LENGTH_LONG).show()
                }
            }
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) tvTime.text = fmt(p.toLong())
            }
            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
                ui.removeCallbacks(hideRunnable)
            }
            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                mp.setTime(sb.progress.toLong())
                showControls(true)
            }
        })

        btnPlay.setOnClickListener {
            if (mp.isPlaying) mp.pause() else mp.play()
            showControls(true)
        }
        findViewById<Button>(R.id.btnAudio).setOnClickListener { showTracks(true) }
        findViewById<Button>(R.id.btnTextTrack).setOnClickListener { showTracks(false) }
        findViewById<Button>(R.id.btnSub).setOnClickListener { pickSub.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnSync).setOnClickListener { showSync() }
        btnSpeed.setOnClickListener {
            speedIndex = (speedIndex + 1) % speeds.size
            mp.setRate(speeds[speedIndex])
            btnSpeed.text = "${speeds[speedIndex]}x".replace(".0x", "x")
        }

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                showControls(topBar.visibility != View.VISIBLE)
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val forward = e.x > findViewById<View>(R.id.root).width / 2f
                val len = mp.length
                val target = mp.time + if (forward) 10_000 else -10_000
                mp.setTime(target.coerceIn(0L, if (len > 0) len else Long.MAX_VALUE))
                showSeekHint(forward)
                return true
            }
        })
        findViewById<View>(R.id.root).setOnTouchListener { _, ev -> detector.onTouchEvent(ev) }
    }

    private fun onPlaying() {
        btnPlay.text = "❚❚"
        if (firstPlay) {
            firstPlay = false
            if (resumeTime > 0) {
                mp.setTime(resumeTime)
                resumeTime = 0
            }
            subFile?.let { mp.addSlave(SUBTITLE_SLAVE, Uri.fromFile(it), true) }
            if (embOffsetMs != 0L) mp.setSpuDelay(embOffsetMs * 1000L)
            if (extActive) mp.setSpuTrack(-1)
            else ui.postDelayed({ autoEnglishSubtitle() }, 1500)
        }
        showControls(true)
    }

    private fun autoEnglishSubtitle() {
        val tracks = mp.spuTracks ?: return
        tracks.firstOrNull {
            val n = it.name ?: ""
            n.contains("english", true) || n.contains("[en", true) || n.contains("eng", true)
        }?.let { mp.setSpuTrack(it.id) }
    }

    private val timeRe = Regex("""(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{1,3})\s*-->\s*(?:(\d+):)?(\d{1,2}):(\d{2})[.,](\d{1,3})""")

    private fun toMs(h: String, m: String, s: String, f: String): Long {
        val frac = f.padEnd(3, '0').take(3).toLong()
        return ((if (h.isEmpty()) 0L else h.toLong()) * 3600 + m.toLong() * 60 + s.toLong()) * 1000 + frac
    }

    private fun parseSubs(text: String): List<Cue> {
        val cues = mutableListOf<Cue>()
        val lines = text.replace("\r", "").split("\n")
        val tagRe = Regex("<[^>]+>")
        val braceRe = Regex("\\{[^}]*\\}")
        var i = 0
        while (i < lines.size) {
            val m = timeRe.find(lines[i])
            if (m != null) {
                val g = m.groupValues
                val start = toMs(g[1], g[2], g[3], g[4])
                val end = toMs(g[5], g[6], g[7], g[8])
                val sb = StringBuilder()
                i++
                while (i < lines.size && lines[i].isNotBlank()) {
                    if (sb.isNotEmpty()) sb.append('\n')
                    sb.append(lines[i])
                    i++
                }
                val clean = sb.toString().replace(tagRe, "").replace(braceRe, "").trim()
                if (clean.isNotEmpty()) cues.add(Cue(start, end, clean))
            } else i++
        }
        return cues.sortedBy { it.start }
    }

    private fun updateExternalSub() {
        val cues = extCues
        if (!extActive || cues == null) {
            if (subText.visibility != View.GONE) subText.visibility = View.GONE
            return
        }
        val t = mp.time - extOffsetMs
        val cue = cues.firstOrNull { t >= it.start && t < it.end }
        if (cue == null) {
            if (subText.visibility != View.GONE) subText.visibility = View.GONE
            lastCue = null
        } else {
            if (cue !== lastCue) {
                subText.text = cue.text
                lastCue = cue
            }
            if (subText.visibility != View.VISIBLE) subText.visibility = View.VISIBLE
        }
    }

    private fun showSync() {
        val external = extActive
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 24, 32, 8)
        }
        val label = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER }
        fun refresh() {
            val v = if (external) extOffsetMs else embOffsetMs
            label.text = "Subtitle delay: %+.1f sec".format(v / 1000.0)
        }
        fun change(delta: Long) {
            if (external) extOffsetMs += delta
            else {
                embOffsetMs += delta
                mp.setSpuDelay(embOffsetMs * 1000L)
            }
            refresh()
        }
        fun row(title: String, sign: Int): View {
            val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            wrap.addView(TextView(this).apply { text = title; setPadding(0, 16, 0, 0) })
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((txt, ms) in listOf("5s" to 5000L, "1s" to 1000L, "0.5s" to 500L, "0.1s" to 100L)) {
                r.addView(Button(this).apply {
                    text = txt
                    minWidth = 0
                    setOnClickListener { change(sign * ms) }
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            wrap.addView(r)
            return wrap
        }
        box.addView(label)
        box.addView(row("Subtitle der se aa raha hai? Jaldi karo:", -1))
        box.addView(row("Subtitle jaldi aa raha hai? Der se karo:", 1))
        refresh()
        AlertDialog.Builder(this)
            .setTitle(if (external) "Subtitle sync" else "Subtitle sync (video wala)")
            .setView(box)
            .setPositiveButton("Done", null)
            .setNeutralButton("Reset") { _, _ ->
                if (external) extOffsetMs = 0L else { embOffsetMs = 0L; mp.setSpuDelay(0L) }
            }
            .show()
    }

    private fun showTracks(audio: Boolean) {
        val tracks = (if (audio) mp.audioTracks else mp.spuTracks) ?: emptyArray()
        val hasExt = !audio && extCues != null
        val off = if (hasExt) 1 else 0
        val names = mutableListOf<String>()
        if (hasExt) names.add("External: $extName")
        tracks.forEach { names.add(it.name ?: "Track ${it.id}") }
        if (names.isEmpty()) {
            Toast.makeText(this, if (audio) "Audio track nahi mila" else "Is video me subtitle nahi hai",
                Toast.LENGTH_SHORT).show()
            return
        }
        val current = if (audio) mp.audioTrack else mp.spuTrack
        val idx = tracks.indexOfFirst { it.id == current }
        val checked = if (!audio && extActive) 0 else if (idx >= 0) idx + off else -1
        AlertDialog.Builder(this)
            .setTitle(if (audio) "Audio" else "Subtitle")
            .setSingleChoiceItems(names.toTypedArray(), checked) { d, which ->
                if (hasExt && which == 0) {
                    extActive = true
                    mp.setSpuTrack(-1)
                } else if (audio) {
                    mp.setAudioTrack(tracks[which].id)
                } else {
                    extActive = false
                    subText.visibility = View.GONE
                    mp.setSpuTrack(tracks[which - off].id)
                }
                d.dismiss()
            }
            .show()
    }

    private fun showControls(show: Boolean) {
        val v = if (show) View.VISIBLE else View.GONE
        topBar.visibility = v
        bottomBar.visibility = v
        ui.removeCallbacks(hideRunnable)
        if (show && mp.isPlaying) ui.postDelayed(hideRunnable, 4000)
    }

    private fun showSeekHint(forward: Boolean) {
        seekText.text = if (forward) "10s  ▶▶" else "◀◀  10s"
        (seekText.layoutParams as FrameLayout.LayoutParams).gravity =
            Gravity.CENTER_VERTICAL or (if (forward) Gravity.END else Gravity.START)
        seekText.requestLayout()
        seekText.animate().cancel()
        seekText.alpha = 1f
        seekText.visibility = View.VISIBLE
        seekText.animate().alpha(0f).setStartDelay(500).setDuration(300)
            .withEndAction { seekText.visibility = View.GONE }.start()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "sub.srt"
    }

    override fun onStart() {
        super.onStart()
        mp.attachViews(vlcLayout, null, true, false)
        pfd?.close()
        pfd = contentResolver.openFileDescriptor(videoUri, "r")
        val media = Media(libVLC, pfd!!.fileDescriptor)
        media.setHWDecoderEnabled(true, false)
        mp.setMedia(media)
        media.release()
        firstPlay = true
        mp.play()
        ui.post(tick)
    }

    override fun onStop() {
        super.onStop()
        ui.removeCallbacks(tick)
        resumeTime = mp.time
        mp.stop()
        mp.detachViews()
        pfd?.close()
        pfd = null
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        mp.release()
        libVLC.release()
    }
}
