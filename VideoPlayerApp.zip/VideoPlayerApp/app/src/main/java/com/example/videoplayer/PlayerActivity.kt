package com.example.videoplayer

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.util.Locale

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var seekText: TextView
    private lateinit var videoUri: Uri
    private var subUri: Uri? = null
    private var subName: String = ""
    private var resumePos = 0L
    private var playWhenReady = true
    private var seekWarned = false

    private val pickSub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            subUri = uri
            subName = displayName(uri)
            resumePos = player?.currentPosition ?: 0L
            load()
            Toast.makeText(this, "Subtitle loaded: $subName", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        videoUri = Uri.parse(intent.getStringExtra("uri"))
        playerView = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        seekText = findViewById(R.id.seekText)
        playerView.subtitleView?.setFractionalTextSize(0.055f)
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
        })
        findViewById<Button>(R.id.btnSub).setOnClickListener { pickSub.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnAudio).setOnClickListener { showTracks(C.TRACK_TYPE_AUDIO) }
        findViewById<Button>(R.id.btnTextTrack).setOnClickListener { showTracks(C.TRACK_TYPE_TEXT) }
        setupGestures()
        savedInstanceState?.let {
            resumePos = it.getLong("pos")
            playWhenReady = it.getBoolean("play", true)
        }
    }

    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) playerView.hideController()
                else playerView.showController()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return true
                val forward = e.x > playerView.width / 2f
                val target = if (forward) p.currentPosition + 10_000 else p.currentPosition - 10_000
                val max = if (p.duration == C.TIME_UNSET) Long.MAX_VALUE else p.duration
                p.seekTo(target.coerceIn(0L, max))
                showSeekHint(forward)
                return true
            }
        })
        playerView.setOnTouchListener { _, ev -> detector.onTouchEvent(ev) }
    }

    private fun showSeekHint(forward: Boolean) {
        seekText.text = if (forward) "10s  ▶▶" else "◀◀  10s"
        (seekText.layoutParams as FrameLayout.LayoutParams).gravity =
            Gravity.CENTER_VERTICAL or (if (forward) Gravity.END else Gravity.START)
        seekText.requestLayout()
        seekText.animate().cancel()
        seekText.alpha = 1f
        seekText.visibility = View.VISIBLE
        seekText.animate().alpha(0f).setStartDelay(500).setDuration(300)
            .withEndAction { seekText.visibility = View.GONE }.start()
    }

    private fun trackName(f: Format, n: Int, type: Int): String {
        val lang = f.language
        val langName = if (lang != null && lang != "und")
            Locale.forLanguageTag(lang).getDisplayLanguage(Locale.ENGLISH).ifBlank { lang }
        else null
        val parts = mutableListOf<String>()
        parts.add(langName ?: f.label ?: (if (type == C.TRACK_TYPE_AUDIO) "Audio $n" else "Subtitle $n"))
        if (langName != null && !f.label.isNullOrBlank() && f.label != langName) parts.add(f.label!!)
        if (type == C.TRACK_TYPE_AUDIO) {
            when (f.channelCount) {
                Format.NO_VALUE -> {}
                1 -> parts.add("Mono")
                2 -> parts.add("Stereo")
                6 -> parts.add("5.1")
                8 -> parts.add("7.1")
                else -> parts.add("${f.channelCount}ch")
            }
            f.sampleMimeType?.substringAfter("/")?.uppercase()?.let { parts.add(it) }
        }
        return parts.joinToString(" • ")
    }

    private fun showTracks(type: Int) {
        val p = player ?: return
        val isText = type == C.TRACK_TYPE_TEXT
        val labels = mutableListOf<String>()
        val refs = mutableListOf<Pair<Tracks.Group, Int>>()
        var checked = -1
        if (isText) labels.add("Off")
        var n = 0
        for (g in p.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                n++
                val ok = g.isTrackSupported(i)
                labels.add(trackName(g.getTrackFormat(i), n, type) + if (ok) "" else "  (phone me supported nahi)")
                refs.add(g to i)
                if (g.isTrackSelected(i)) checked = labels.size - 1
            }
        }
        if (refs.isEmpty()) {
            Toast.makeText(this, if (isText) "Is video me subtitle nahi hai" else "Audio track nahi mila",
                Toast.LENGTH_SHORT).show()
            return
        }
        if (isText && checked == -1) checked = 0
        val offset = if (isText) 1 else 0
        AlertDialog.Builder(this)
            .setTitle(if (isText) "Subtitle" else "Audio")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                val b = p.trackSelectionParameters.buildUpon()
                if (isText && which == 0) {
                    b.setTrackTypeDisabled(type, true)
                } else {
                    val (g, i) = refs[which - offset]
                    b.setTrackTypeDisabled(type, false)
                        .clearOverridesOfType(type)
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, listOf(i)))
                }
                p.trackSelectionParameters = b.build()
                d.dismiss()
            }
            .show()
    }

    override fun onStart() {
        super.onStart()
        val extractors = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this, extractors))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        p.setSeekParameters(SeekParameters.CLOSEST_SYNC)
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity, "Error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && !seekWarned && !p.isCurrentMediaItemSeekable) {
                    seekWarned = true
                    val fmt = p.videoFormat?.containerMimeType ?: "unknown"
                    Toast.makeText(this@PlayerActivity,
                        "Is file me seek support nahi hai (format: $fmt)", Toast.LENGTH_LONG).show()
                }
            }
        })
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage("en")
            .build()
        player = p
        playerView.player = p
        load()
    }

    private fun load() {
        val p = player ?: return
        val item = MediaItem.Builder().setUri(videoUri).apply {
            subUri?.let { u ->
                val ext = subName.substringAfterLast('.', "").lowercase()
                val mime = when (ext) {
                    "vtt" -> MimeTypes.TEXT_VTT
                    "ass", "ssa" -> MimeTypes.TEXT_SSA
                    "ttml", "xml" -> MimeTypes.APPLICATION_TTML
                    else -> MimeTypes.APPLICATION_SUBRIP
                }
                setSubtitleConfigurations(
                    listOf(
                        MediaItem.SubtitleConfiguration.Builder(u)
                            .setMimeType(mime)
                            .setLanguage("en")
                            .setLabel("English (external)")
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                            .build()
                    )
                )
            }
        }.build()
        p.setMediaItem(item, resumePos)
        p.playWhenReady = playWhenReady
        p.prepare()
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "sub.srt"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong("pos", player?.currentPosition ?: resumePos)
        outState.putBoolean("play", player?.playWhenReady ?: true)
    }

    override fun onStop() {
        super.onStop()
        player?.let {
            resumePos = it.currentPosition
            playWhenReady = it.playWhenReady
            it.release()
        }
        player = null
        playerView.player = null
    }
}
