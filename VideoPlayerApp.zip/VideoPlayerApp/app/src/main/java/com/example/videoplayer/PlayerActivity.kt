package com.example.videoplayer

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.text.CueGroup
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.ExtractorsFactory
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import java.io.File
import java.util.Locale

/**
 * Primary player (ExoPlayer: hardware decoding, frame-accurate subtitles).
 * If a file cannot be seeked by ExoPlayer, it hands over to VlcPlayerActivity.
 */
class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var topBar: View
    private lateinit var seekText: TextView
    private lateinit var videoUri: Uri
    private var subUri: Uri? = null
    private var subName: String = ""
    private var resumePos = 0L
    private var playWhenReady = true
    private var switched = false
    private var mkvIndex: MkvIndex? = null
    private var scanDone = false
    private var scanning = false
    private var started = false
    private lateinit var delayedSubs: SubtitleView
    private val ui = Handler(Looper.getMainLooper())
    private var extOffsetMs = 0L   // external subtitle file shift (both directions)
    private var embOffsetMs = 0L   // embedded subtitle delay (only later, >= 0)

    private val pickSub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            subUri = uri
            subName = displayName(uri)
            extOffsetMs = 0L
            applyEmbeddedMode()
            resumePos = player?.currentPosition ?: 0L
            load()
            Toast.makeText(this, "Subtitle loaded: $subName", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        videoUri = Uri.parse(intent.getStringExtra("uri"))
        playerView = findViewById(R.id.playerView)
        topBar = findViewById(R.id.topBar)
        seekText = findViewById(R.id.seekText)
        playerView.subtitleView?.setFractionalTextSize(0.055f)
        delayedSubs = findViewById(R.id.delayedSubs)
        delayedSubs.setUserDefaultStyle()
        delayedSubs.setFractionalTextSize(0.055f)
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            topBar.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
        })
        findViewById<Button>(R.id.btnSub).setOnClickListener { pickSub.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnAudio).setOnClickListener { showTracks(C.TRACK_TYPE_AUDIO) }
        findViewById<Button>(R.id.btnTextTrack).setOnClickListener { showTracks(C.TRACK_TYPE_TEXT) }
        findViewById<Button>(R.id.btnSync).setOnClickListener { showSync() }
        setupGestures()
        savedInstanceState?.let {
            resumePos = it.getLong("pos")
            playWhenReady = it.getBoolean("play", true)
        }
    }

    private fun setupGestures() {
        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (playerView.isControllerFullyVisible) playerView.hideController()
                else playerView.showController()
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val p = player ?: return true
                val forward = e.x > playerView.width / 2f
                val target = if (forward) p.currentPosition + 10_000 else p.currentPosition - 10_000
                val max = if (p.duration == C.TIME_UNSET) Long.MAX_VALUE else p.duration
                p.seekTo(target.coerceIn(0L, max))
                showSeekHint(forward)
                return true
            }
        })
        playerView.setOnTouchListener { _, ev -> detector.onTouchEvent(ev) }
    }

    private fun showSeekHint(forward: Boolean) {
        seekText.text = if (forward) "10s  ▶▶" else "◀◀  10s"
        (seekText.layoutParams as FrameLayout.LayoutParams).gravity =
            Gravity.CENTER_VERTICAL or (if (forward) Gravity.END else Gravity.START)
        seekText.requestLayout()
        seekText.animate().cancel()
        seekText.alpha = 1f
        seekText.visibility = View.VISIBLE
        seekText.animate().alpha(0f).setStartDelay(500).setDuration(300)
            .withEndAction { seekText.visibility = View.GONE }.start()
    }

    private fun trackName(f: Format, n: Int, type: Int): String {
        val lang = f.language
        val langName = if (lang != null && lang != "und")
            Locale.forLanguageTag(lang).getDisplayLanguage(Locale.ENGLISH).ifBlank { lang }
        else null
        val parts = mutableListOf<String>()
        parts.add(langName ?: f.label ?: (if (type == C.TRACK_TYPE_AUDIO) "Audio $n" else "Subtitle $n"))
        if (langName != null && !f.label.isNullOrBlank() && f.label != langName) parts.add(f.label!!)
        if (type == C.TRACK_TYPE_AUDIO) {
            when (f.channelCount) {
                Format.NO_VALUE -> {}
                1 -> parts.add("Mono")
                2 -> parts.add("Stereo")
                6 -> parts.add("5.1")
                8 -> parts.add("7.1")
                else -> parts.add("${f.channelCount}ch")
            }
            f.sampleMimeType?.substringAfter("/")?.uppercase()?.let { parts.add(it) }
        }
        return parts.joinToString(" • ")
    }

    private fun showTracks(type: Int) {
        val p = player ?: return
        val isText = type == C.TRACK_TYPE_TEXT
        val labels = mutableListOf<String>()
        val refs = mutableListOf<Pair<Tracks.Group, Int>>()
        var checked = -1
        if (isText) labels.add("Off")
        var n = 0
        for (g in p.currentTracks.groups) {
            if (g.type != type) continue
            for (i in 0 until g.length) {
                n++
                val ok = g.isTrackSupported(i)
                labels.add(trackName(g.getTrackFormat(i), n, type) + if (ok) "" else "  (phone me supported nahi)")
                refs.add(g to i)
                if (g.isTrackSelected(i)) checked = labels.size - 1
            }
        }
        if (refs.isEmpty()) {
            Toast.makeText(this, if (isText) "Is video me subtitle nahi hai" else "Audio track nahi mila",
                Toast.LENGTH_SHORT).show()
            return
        }
        if (isText && checked == -1) checked = 0
        val offset = if (isText) 1 else 0
        AlertDialog.Builder(this)
            .setTitle(if (isText) "Subtitle" else "Audio")
            .setSingleChoiceItems(labels.toTypedArray(), checked) { d, which ->
                val b = p.trackSelectionParameters.buildUpon()
                if (isText && which == 0) {
                    b.setTrackTypeDisabled(type, true)
                } else {
                    val (g, i) = refs[which - offset]
                    b.setTrackTypeDisabled(type, false)
                        .clearOverridesOfType(type)
                        .setOverrideForType(TrackSelectionOverride(g.mediaTrackGroup, listOf(i)))
                }
                p.trackSelectionParameters = b.build()
                d.dismiss()
            }
            .show()
    }

    override fun onStart() {
        super.onStart()
        started = true
        if (scanDone) {
            startPlayer()
        } else if (!scanning) {
            scanning = true
            Thread {
                val idx = try { MkvScanner.scan(applicationContext, videoUri) } catch (e: Throwable) { null }
                runOnUiThread {
                    mkvIndex = idx
                    scanDone = true
                    scanning = false
                    if (started && player == null) startPlayer()
                }
            }.start()
        }
    }

    private fun startPlayer() {
        val baseExtractors = DefaultExtractorsFactory().setConstantBitrateSeekingEnabled(true)
        val extractors: ExtractorsFactory =
            mkvIndex?.let { IndexedExtractorsFactory(it, baseExtractors) } ?: baseExtractors
        val renderers = DefaultRenderersFactory(this).setEnableDecoderFallback(true)
        val p = ExoPlayer.Builder(this, renderers)
            .setMediaSourceFactory(DefaultMediaSourceFactory(this, extractors))
            .setSeekBackIncrementMs(10_000)
            .setSeekForwardIncrementMs(10_000)
            .build()
        p.setSeekParameters(SeekParameters.EXACT)
        p.addListener(object : Player.Listener {
            override fun onCues(cueGroup: CueGroup) {
                // Embedded subtitle delay: show cues later by embOffsetMs
                if (subUri != null || embOffsetMs <= 0L) return
                val cues = cueGroup.cues
                ui.postDelayed({ delayedSubs.setCues(cues) }, embOffsetMs)
            }
            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (embOffsetMs > 0L) {
                    ui.removeCallbacksAndMessages(null)
                    delayedSubs.setCues(emptyList())
                }
            }
            override fun onPlayerError(error: PlaybackException) {
                Toast.makeText(this@PlayerActivity, "Error: ${error.errorCodeName}", Toast.LENGTH_LONG).show()
            }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && !switched && !p.isCurrentMediaItemSeekable) {
                    switched = true
                    val pos = p.currentPosition
                    Toast.makeText(this@PlayerActivity,
                        "Seek ke liye VLC engine use ho raha hai", Toast.LENGTH_SHORT).show()
                    startActivity(
                        Intent(this@PlayerActivity, VlcPlayerActivity::class.java)
                            .putExtra("uri", videoUri.toString())
                            .putExtra("title", intent.getStringExtra("title"))
                            .putExtra("pos", pos)
                    )
                    finish()
                }
            }
        })
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage("en")
            .build()
        player = p
        playerView.player = p
        load()
    }

    private fun load() {
        val p = player ?: return
        val item = MediaItem.Builder().setUri(videoUri).apply {
            subUri?.let { u ->
                val ext = subName.substringAfterLast('.', "").lowercase()
                val mime = when (ext) {
                    "vtt" -> MimeTypes.TEXT_VTT
                    "ass", "ssa" -> MimeTypes.TEXT_SSA
                    "ttml", "xml" -> MimeTypes.APPLICATION_TTML
                    else -> MimeTypes.APPLICATION_SUBRIP
                }
                val effUri = if (extOffsetMs != 0L) (buildShiftedSub(ext, extOffsetMs) ?: u) else u
                setSubtitleConfigurations(
                    listOf(
                        MediaItem.SubtitleConfiguration.Builder(effUri)
                            .setMimeType(mime)
                            .setLanguage("en")
                            .setLabel("English (external)")
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                            .build()
                    )
                )
            }
        }.build()
        p.setMediaItem(item, resumePos)
        p.playWhenReady = playWhenReady
        p.prepare()
    }

    // ---------- Subtitle sync ----------

    private val timeRe = Regex("""(?:(\d+):)?(\d{1,2}):(\d{2})([.,])(\d{1,3})""")

    private fun readSubText(uri: Uri): String? = try {
        val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return null
        var t = String(bytes, Charsets.UTF_8)
        if (t.contains('\uFFFD')) t = String(bytes, Charsets.ISO_8859_1)
        t.removePrefix("\uFEFF")
    } catch (e: Exception) { null }

    private fun fmtTime(ms: Long, sep: Char): String {
        val t = ms.coerceAtLeast(0L)
        return "%02d:%02d:%02d%c%03d".format(t / 3_600_000, t / 60_000 % 60, t / 1000 % 60, sep, t % 1000)
    }

    private fun shiftSrtVtt(text: String, delta: Long): String =
        text.replace("\r", "").split("\n").joinToString("\n") { line ->
            if (!line.contains("-->")) line
            else timeRe.replace(line) { m ->
                val g = m.groupValues
                val frac = g[5].padEnd(3, '0').take(3).toLong()
                val h = if (g[1].isEmpty()) 0L else g[1].toLong()
                val ms = (h * 3600 + g[2].toLong() * 60 + g[3].toLong()) * 1000 + frac
                fmtTime(ms + delta, g[4][0])
            }
        }

    private val assTimeRe = Regex("""(\d+):(\d{2}):(\d{2})\.(\d{2})""")

    private fun shiftAssTime(t: String, delta: Long): String {
        val m = assTimeRe.find(t.trim()) ?: return t
        val g = m.groupValues
        val ms = (g[1].toLong() * 3600 + g[2].toLong() * 60 + g[3].toLong()) * 1000 + g[4].toLong() * 10
        val v = (ms + delta).coerceAtLeast(0L)
        return "%d:%02d:%02d.%02d".format(v / 3_600_000, v / 60_000 % 60, v / 1000 % 60, v % 1000 / 10)
    }

    private fun shiftAss(text: String, delta: Long): String =
        text.replace("\r", "").split("\n").joinToString("\n") { line ->
            if (!line.startsWith("Dialogue:")) line
            else {
                val parts = line.split(",", limit = 10).toMutableList()
                if (parts.size >= 10) {
                    parts[1] = shiftAssTime(parts[1], delta)
                    parts[2] = shiftAssTime(parts[2], delta)
                }
                parts.joinToString(",")
            }
        }

    /** Writes a time-shifted copy of the external subtitle to cache; null on failure. */
    private fun buildShiftedSub(ext: String, delta: Long): Uri? {
        val src = subUri ?: return null
        val text = readSubText(src) ?: return null
        val out = if (ext == "ass" || ext == "ssa") shiftAss(text, delta) else shiftSrtVtt(text, delta)
        return try {
            val f = File(cacheDir, "sub_shifted.${if (ext.isEmpty()) "srt" else ext}")
            f.writeText(out, Charsets.UTF_8)
            Uri.fromFile(f)
        } catch (e: Exception) { null }
    }

    private fun applyEmbeddedMode() {
        val on = embOffsetMs > 0L && subUri == null
        ui.removeCallbacksAndMessages(null)
        delayedSubs.setCues(emptyList())
        delayedSubs.visibility = if (on) View.VISIBLE else View.GONE
        playerView.subtitleView?.visibility = if (on) View.GONE else View.VISIBLE
    }

    private fun showSync() {
        val external = subUri != null
        val startOffset = extOffsetMs
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 24, 32, 8)
        }
        val label = TextView(this).apply { textSize = 20f; gravity = Gravity.CENTER }
        fun refresh() {
            val v = if (external) extOffsetMs else embOffsetMs
            label.text = "Subtitle delay: %+.1f sec".format(v / 1000.0)
        }
        fun change(delta: Long) {
            if (external) {
                extOffsetMs += delta
            } else {
                val n = embOffsetMs + delta
                if (n < 0L) {
                    Toast.makeText(this, "Video wale subtitle ko jaldi karne ke liye VLC engine use karo",
                        Toast.LENGTH_LONG).show()
                } else {
                    embOffsetMs = n
                    applyEmbeddedMode()
                }
            }
            refresh()
        }
        fun row(title: String, sign: Int): View {
            val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            wrap.addView(TextView(this).apply { text = title; setPadding(0, 16, 0, 0) })
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((txt, ms) in listOf("5s" to 5000L, "1s" to 1000L, "0.5s" to 500L, "0.1s" to 100L)) {
                r.addView(Button(this).apply {
                    text = txt
                    minWidth = 0
                    setOnClickListener { change(sign * ms) }
                }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            }
            wrap.addView(r)
            return wrap
        }
        box.addView(label)
        box.addView(row("Subtitle der se aa raha hai? Jaldi karo:", -1))
        box.addView(row("Subtitle jaldi aa raha hai? Der se karo:", 1))
        refresh()
        val b = AlertDialog.Builder(this)
            .setTitle(if (external) "Subtitle sync" else "Subtitle sync (video wala)")
            .setView(box)
            .setPositiveButton("Done", null)
            .setNeutralButton("Reset") { _, _ ->
                if (external) extOffsetMs = 0L else { embOffsetMs = 0L; applyEmbeddedMode() }
            }
            .setOnDismissListener {
                // External file shift needs a reload with the shifted copy
                if (external && extOffsetMs != startOffset) {
                    val p = player
                    if (p != null) {
                        resumePos = p.currentPosition
                        playWhenReady = p.playWhenReady
                        load()
                    }
                }
            }
        if (!external) {
            b.setNegativeButton("VLC me kholo") { _, _ ->
                startActivity(
                    Intent(this, VlcPlayerActivity::class.java)
                        .putExtra("uri", videoUri.toString())
                        .putExtra("title", intent.getStringExtra("title"))
                        .putExtra("pos", player?.currentPosition ?: 0L)
                )
                finish()
            }
        }
        b.show()
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "sub.srt"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong("pos", player?.currentPosition ?: resumePos)
        outState.putBoolean("play", player?.playWhenReady ?: true)
    }

    override fun onStop() {
        super.onStop()
        started = false
        ui.removeCallbacksAndMessages(null)
        player?.let {
            resumePos = it.currentPosition
            playWhenReady = it.playWhenReady
            it.release()
        }
        player = null
        playerView.player = null
    }
}
