package com.example.videoplayer

import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File

class PlayerActivity : AppCompatActivity() {
    private lateinit var libVLC: LibVLC
    private lateinit var mp: MediaPlayer
    private lateinit var vlcLayout: VLCVideoLayout
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var seekBar: SeekBar
    private lateinit var tvTime: TextView
    private lateinit var tvTotal: TextView
    private lateinit var btnPlay: Button
    private lateinit var btnSpeed: Button
    private lateinit var seekText: TextView
    private lateinit var videoUri: Uri

    private var pfd: ParcelFileDescriptor? = null
    private var subFile: File? = null
    private var resumeTime = 0L
    private var dragging = false
    private var firstPlay = true
    private var speedIndex = 0
    private val speeds = floatArrayOf(1f, 1.25f, 1.5f, 2f, 0.75f)
    private val ui = Handler(Looper.getMainLooper())
    private val hideRunnable = Runnable { showControls(false) }

    private val pickSub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = displayName(uri).replace('/', '_')
            val f = File(cacheDir, name)
            contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            subFile = f
            mp.addSlave(Media.Slave.Type.Subtitle, Uri.fromFile(f), true)
            Toast.makeText(this, "Subtitle loaded: $name", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        videoUri = Uri.parse(intent.getStringExtra("uri"))

        vlcLayout = findViewById(R.id.vlcLayout)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        seekBar = findViewById(R.id.seekBar)
        tvTime = findViewById(R.id.tvTime)
        tvTotal = findViewById(R.id.tvTotal)
        btnPlay = findViewById(R.id.btnPlay)
        btnSpeed = findViewById(R.id.btnSpeed)
        seekText = findViewById(R.id.seekText)

        libVLC = LibVLC(this, arrayListOf("--no-drop-late-frames", "--no-skip-frames"))
        mp = MediaPlayer(libVLC)

        mp.setEventListener { ev ->
            val type = ev.type
            val timeMs = ev.timeChanged
            val lenMs = ev.lengthChanged
            runOnUiThread {
                when (type) {
                    MediaPlayer.Event.Playing -> onPlaying()
                    MediaPlayer.Event.Paused, MediaPlayer.Event.Stopped -> btnPlay.text = "▶"
                    MediaPlayer.Event.LengthChanged -> {
                        seekBar.max = lenMs.toInt()
                        tvTotal.text = fmt(lenMs)
                    }
                    MediaPlayer.Event.TimeChanged -> if (!dragging) {
                        seekBar.progress = timeMs.toInt()
                        tvTime.text = fmt(timeMs)
                    }
                    MediaPlayer.Event.EncounteredError ->
                        Toast.makeText(this, "Video play nahi ho paya", Toast.LENGTH_LONG).show()
                }
            }
        }

        seekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) tvTime.text = fmt(p.toLong())
            }
            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
                ui.removeCallbacks(hideRunnable)
            }
            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                mp.setTime(sb.progress.toLong())
                showControls(true)
            }
        })

        btnPlay.setOnClickListener {
            if (mp.isPlaying) mp.pause() else mp.play()
            showControls(true)
        }
        findViewById<Button>(R.id.btnAudio).setOnClickListener { showTracks(true) }
        findViewById<Button>(R.id.btnTextTrack).setOnClickListener { showTracks(false) }
        findViewById<Button>(R.id.btnSub).setOnClickListener { pickSub.launch(arrayOf("*/*")) }
        findViewById<Button>(R.id.btnSubMinus).setOnClickListener { changeSubDelay(-200) }
        findViewById<Button>(R.id.btnSubPlus).setOnClickListener { changeSubDelay(200) }
        btnSpeed.setOnClickListener {
            speedIndex = (speedIndex + 1) % speeds.size
            mp.setRate(speeds[speedIndex])
            btnSpeed.text = "${speeds[speedIndex]}x".replace(".0x", "x")
        }

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent) = true
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                showControls(topBar.visibility != View.VISIBLE)
                return true
            }
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val forward = e.x > findViewById<View>(R.id.root).width / 2f
                val len = mp.length
                val target = mp.time + if (forward) 10_000 else -10_000
                mp.setTime(target.coerceIn(0L, if (len > 0) len else Long.MAX_VALUE))
                showSeekHint(forward)
                return true
            }
        })
        findViewById<View>(R.id.root).setOnTouchListener { _, ev -> detector.onTouchEvent(ev) }
    }

    private fun onPlaying() {
        btnPlay.text = "❚❚"
        if (firstPlay) {
            firstPlay = false
            if (resumeTime > 0) {
                mp.setTime(resumeTime)
                resumeTime = 0
            }
            subFile?.let { mp.addSlave(Media.Slave.Type.Subtitle, Uri.fromFile(it), true) }
            ui.postDelayed({ autoEnglishSubtitle() }, 1500)
        }
        showControls(true)
    }

    private fun autoEnglishSubtitle() {
        val tracks = mp.spuTracks ?: return
        tracks.firstOrNull {
            val n = it.name ?: ""
            n.contains("english", true) || n.contains("[en", true) || n.contains("eng", true)
        }?.let { mp.setSpuTrack(it.id) }
    }

    private fun changeSubDelay(deltaMs: Int) {
        val d = mp.getSpuDelay() + deltaMs * 1000L
        mp.setSpuDelay(d)
        Toast.makeText(this, "Subtitle delay: %.1f sec".format(d / 1_000_000.0), Toast.LENGTH_SHORT).show()
    }

    private fun showTracks(audio: Boolean) {
        val tracks = (if (audio) mp.audioTracks else mp.spuTracks) ?: emptyArray()
        if (tracks.isEmpty()) {
            Toast.makeText(this, if (audio) "Audio track nahi mila" else "Is video me subtitle nahi hai",
                Toast.LENGTH_SHORT).show()
            return
        }
        val current = if (audio) mp.audioTrack else mp.spuTrack
        val names = tracks.map { it.name ?: "Track ${it.id}" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(if (audio) "Audio" else "Subtitle")
            .setSingleChoiceItems(names, tracks.indexOfFirst { it.id == current }) { d, which ->
                if (audio) mp.setAudioTrack(tracks[which].id) else mp.setSpuTrack(tracks[which].id)
                d.dismiss()
            }
            .show()
    }

    private fun showControls(show: Boolean) {
        val v = if (show) View.VISIBLE else View.GONE
        topBar.visibility = v
        bottomBar.visibility = v
        ui.removeCallbacks(hideRunnable)
        if (show && mp.isPlaying) ui.postDelayed(hideRunnable, 4000)
    }

    private fun showSeekHint(forward: Boolean) {
        seekText.text = if (forward) "10s  ▶▶" else "◀◀  10s"
        (seekText.layoutParams as FrameLayout.LayoutParams).gravity =
            Gravity.CENTER_VERTICAL or (if (forward) Gravity.END else Gravity.START)
        seekText.requestLayout()
        seekText.animate().cancel()
        seekText.alpha = 1f
        seekText.visibility = View.VISIBLE
        seekText.animate().alpha(0f).setStartDelay(500).setDuration(300)
            .withEndAction { seekText.visibility = View.GONE }.start()
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
        else "%d:%02d".format(s / 60, s % 60)
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "sub.srt"
    }

    override fun onStart() {
        super.onStart()
        mp.attachViews(vlcLayout, null, true, false)
        pfd?.close()
        pfd = contentResolver.openFileDescriptor(videoUri, "r")
        val media = Media(libVLC, pfd!!.fileDescriptor)
        media.setHWDecoderEnabled(true, false)
        mp.setMedia(media)
        media.release()
        firstPlay = true
        mp.play()
    }

    override fun onStop() {
        super.onStop()
        resumeTime = mp.time
        mp.stop()
        mp.detachViews()
        pfd?.close()
        pfd = null
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
        mp.release()
        libVLC.release()
    }
}
