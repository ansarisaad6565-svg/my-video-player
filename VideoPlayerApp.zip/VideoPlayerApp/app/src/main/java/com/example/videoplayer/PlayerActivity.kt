package com.example.videoplayer

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var btnSub: Button
    private lateinit var videoUri: Uri
    private var subUri: Uri? = null
    private var subName: String = ""
    private var resumePos = 0L
    private var playWhenReady = true

    private val pickSub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            subUri = uri
            subName = displayName(uri)
            resumePos = player?.currentPosition ?: 0L
            load()
            Toast.makeText(this, "Subtitle loaded: $subName", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        videoUri = Uri.parse(intent.getStringExtra("uri"))
        playerView = findViewById(R.id.playerView)
        btnSub = findViewById(R.id.btnSub)
        playerView.subtitleView?.setFractionalTextSize(0.055f)
        playerView.setControllerVisibilityListener(PlayerView.ControllerVisibilityListener { vis ->
            btnSub.visibility = if (vis == View.VISIBLE) View.VISIBLE else View.GONE
        })
        btnSub.setOnClickListener { pickSub.launch(arrayOf("*/*")) }
        savedInstanceState?.let {
            resumePos = it.getLong("pos")
            playWhenReady = it.getBoolean("play", true)
        }
    }

    override fun onStart() {
        super.onStart()
        val p = ExoPlayer.Builder(this).build()
        p.trackSelectionParameters = p.trackSelectionParameters.buildUpon()
            .setPreferredTextLanguage("en")
            .build()
        player = p
        playerView.player = p
        load()
    }

    private fun load() {
        val p = player ?: return
        val item = MediaItem.Builder().setUri(videoUri).apply {
            subUri?.let { u ->
                val ext = subName.substringAfterLast('.', "").lowercase()
                val mime = when (ext) {
                    "vtt" -> MimeTypes.TEXT_VTT
                    "ass", "ssa" -> MimeTypes.TEXT_SSA
                    "ttml", "xml" -> MimeTypes.APPLICATION_TTML
                    else -> MimeTypes.APPLICATION_SUBRIP
                }
                setSubtitleConfigurations(
                    listOf(
                        MediaItem.SubtitleConfiguration.Builder(u)
                            .setMimeType(mime)
                            .setLanguage("en")
                            .setLabel("English (external)")
                            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                            .build()
                    )
                )
            }
        }.build()
        p.setMediaItem(item, resumePos)
        p.playWhenReady = playWhenReady
        p.prepare()
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0 && c.moveToFirst()) return c.getString(i)
        }
        return uri.lastPathSegment ?: "sub.srt"
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putLong("pos", player?.currentPosition ?: resumePos)
        outState.putBoolean("play", player?.playWhenReady ?: true)
    }

    override fun onStop() {
        super.onStop()
        player?.let {
            resumePos = it.currentPosition
            playWhenReady = it.playWhenReady
            it.release()
        }
        player = null
        playerView.player = null
    }
}
