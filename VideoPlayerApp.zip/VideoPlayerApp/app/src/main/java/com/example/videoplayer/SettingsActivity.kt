package com.example.videoplayer

import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        AppTheme.apply(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        findViewById<TextView>(R.id.themeValue).text = AppTheme.names[AppTheme.index(this)]
        findViewById<View>(R.id.rowTheme).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Theme")
                .setSingleChoiceItems(AppTheme.names.toTypedArray(), AppTheme.index(this)) { d, which ->
                    AppTheme.set(this, which)
                    d.dismiss()
                    recreate()
                }
                .show()
        }

        findViewById<View>(R.id.rowClear).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Resume history")
                .setMessage("Sab videos ki yaad rakhi hui position hata dein?")
                .setPositiveButton("Haan") { _, _ ->
                    ResumeStore.clearAll(this)
                    Toast.makeText(this, "Resume history saaf ho gayi", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Nahi", null)
                .show()
        }

        val ver = try {
            packageManager.getPackageInfo(packageName, 0).versionName ?: ""
        } catch (e: Exception) { "" }
        findViewById<TextView>(R.id.versionValue).text = "v$ver"
    }
}
