package com.example.videoplayer

import android.content.Context
import android.net.Uri
import android.system.Os
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.Extractor
import androidx.media3.extractor.ExtractorInput
import androidx.media3.extractor.ExtractorOutput
import androidx.media3.extractor.PositionHolder
import androidx.media3.extractor.SeekMap
import androidx.media3.extractor.SeekPoint
import androidx.media3.extractor.TrackOutput
import java.io.FileDescriptor
import java.nio.ByteBuffer

/** Cluster table of an MKV file: start time (us) and absolute byte position of every cluster. */
class MkvIndex(val timesUs: LongArray, val positions: LongArray, val durationUs: Long)

object MkvScanner {
    private const val ID_EBML = 0x1A45DFA3L
    private const val ID_SEGMENT = 0x18538067L
    private const val ID_INFO = 0x1549A966L
    private const val ID_CLUSTER = 0x1F43B675L
    private const val ID_TIMECODE = 0xE7L
    private const val ID_TIMESCALE = 0x2AD7B1L
    private const val ID_DURATION = 0x4489L

    private class H(val id: Long, val size: Long, val len: Int)

    private fun parse(b: ByteArray, off: Int, end: Int): H? {
        if (off >= end) return null
        val b0 = b[off].toInt() and 0xFF
        if (b0 == 0) return null
        val idLen = Integer.numberOfLeadingZeros(b0) - 24 + 1
        if (idLen > 4 || off + idLen >= end) return null
        var id = 0L
        for (i in 0 until idLen) id = (id shl 8) or (b[off + i].toLong() and 0xFF)
        val s0 = b[off + idLen].toInt() and 0xFF
        if (s0 == 0) return null
        val sLen = Integer.numberOfLeadingZeros(s0) - 24 + 1
        if (off + idLen + sLen > end) return null
        val mask = 0xFF shr sLen
        var v = (s0 and mask).toLong()
        var allOnes = v == mask.toLong()
        for (i in 1 until sLen) {
            val x = b[off + idLen + i].toLong() and 0xFF
            v = (v shl 8) or x
            if (x != 0xFFL) allOnes = false
        }
        return H(id, if (allOnes) -1L else v, idLen + sLen)
    }

    private fun uint(b: ByteArray, off: Int, len: Int): Long {
        var v = 0L
        for (i in 0 until len) v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        return v
    }

    /** Returns null if the file is not an MKV or cannot be indexed. */
    fun scan(ctx: Context, uri: Uri): MkvIndex? {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: return null
        pfd.use {
            val size = try { Os.fstat(it.fileDescriptor).st_size } catch (e: Exception) { it.statSize }
            return scanFd(it.fileDescriptor, size)
        }
    }

    private fun scanFd(fd: FileDescriptor, fileSize: Long): MkvIndex? {
        fun read(off: Long, b: ByteArray, len: Int): Int =
            try { Os.pread(fd, b, 0, len, off) } catch (e: Exception) { -1 }

        val buf = ByteArray(64)
        var n = read(0, buf, 16)
        if (n < 8) return null
        val eh = parse(buf, 0, n) ?: return null
        if (eh.id != ID_EBML || eh.size < 0) return null
        var pos = eh.len + eh.size
        n = read(pos, buf, 16)
        if (n < 8) return null
        val sh = parse(buf, 0, n) ?: return null
        if (sh.id != ID_SEGMENT) return null
        pos += sh.len

        var scale = 1_000_000L
        var durationTicks = -1.0
        val tcs = ArrayList<Long>()
        val poss = ArrayList<Long>()
        var complete = false

        while (true) {
            if (pos >= fileSize - 1) { complete = true; break }
            n = read(pos, buf, 64)
            if (n <= 0) break
            val h = parse(buf, 0, n) ?: break
            if (h.id == ID_CLUSTER) {
                var o = h.len
                var found = -1L
                var guard = 0
                while (o < n && guard++ < 8) {
                    val c = parse(buf, o, n) ?: break
                    if (c.size < 0 || c.size > 64) break
                    if (c.id == ID_TIMECODE && c.size in 1..8 && o + c.len + c.size <= n) {
                        found = uint(buf, o + c.len, c.size.toInt())
                        break
                    }
                    o += (c.len + c.size).toInt()
                }
                if (found < 0) break
                tcs.add(found)
                poss.add(pos)
            } else if (h.id == ID_INFO && h.size in 1..4096) {
                val ib = ByteArray(h.size.toInt())
                val m = read(pos + h.len, ib, ib.size)
                var o = 0
                while (o < m) {
                    val c = parse(ib, o, m) ?: break
                    if (c.size < 0 || o + c.len + c.size > m) break
                    val ds = o + c.len
                    val sz = c.size.toInt()
                    if (c.id == ID_TIMESCALE && sz in 1..8) scale = uint(ib, ds, sz)
                    else if (c.id == ID_DURATION) {
                        val bb = ByteBuffer.wrap(ib, ds, sz)
                        durationTicks = when (sz) {
                            4 -> bb.float.toDouble()
                            8 -> bb.double
                            else -> -1.0
                        }
                    }
                    o = ds + sz
                }
            }
            if (h.size < 0) break
            pos += h.len + h.size
        }

        if (!complete || tcs.size < 2) return null
        val times = LongArray(tcs.size) { tcs[it] * scale / 1000 }
        val positions = LongArray(poss.size) { poss[it] }
        for (i in 1 until times.size) if (times[i] < times[i - 1]) return null
        val last = times.last()
        val dur = if (durationTicks > 0) (durationTicks * scale / 1000).toLong()
        else last + (last - times[times.size - 2]).coerceAtLeast(1_000_000L)
        return MkvIndex(times, positions, dur)
    }
}

class IndexSeekMap(private val idx: MkvIndex, private val durUs: Long) : SeekMap {
    override fun isSeekable(): Boolean = true
    override fun getDurationUs(): Long = durUs
    override fun getSeekPoints(timeUs: Long): SeekMap.SeekPoints {
        val t = idx.timesUs
        var lo = 0
        var hi = t.size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (t[mid] <= timeUs) lo = mid else hi = mid - 1
        }
        return SeekMap.SeekPoints(SeekPoint(t[lo], idx.positions[lo]))
    }
}

/** Wraps an extractor; if it reports an unseekable stream, substitutes our cluster index. */
class IndexingExtractor(private val delegate: Extractor, private val idx: MkvIndex) : Extractor {
    override fun sniff(input: ExtractorInput): Boolean = delegate.sniff(input)

    override fun init(output: ExtractorOutput) {
        delegate.init(object : ExtractorOutput {
            override fun track(id: Int, type: Int): TrackOutput = output.track(id, type)
            override fun endTracks() = output.endTracks()
            override fun seekMap(seekMap: SeekMap) {
                if (seekMap.isSeekable) {
                    output.seekMap(seekMap)
                } else {
                    val d = seekMap.durationUs
                    output.seekMap(IndexSeekMap(idx, if (d > 0) d else idx.durationUs))
                }
            }
        })
    }

    override fun read(input: ExtractorInput, seekPosition: PositionHolder): Int =
        delegate.read(input, seekPosition)

    override fun seek(position: Long, timeUs: Long) = delegate.seek(position, timeUs)

    override fun release() = delegate.release()
}

class IndexedExtractorsFactory(private val idx: MkvIndex) : DefaultExtractorsFactory() {
    override fun createExtractors(
        uri: Uri,
        responseHeaders: Map<String, List<String>>
    ): Array<Extractor> {
        return super.createExtractors(uri, responseHeaders)
            .map { IndexingExtractor(it, idx) as Extractor }
            .toTypedArray()
    }
}
