package com.example.videoplayer

import android.content.Context
import android.net.Uri
import android.system.Os
import androidx.media3.extractor.DefaultExtractorsFactory
import androidx.media3.extractor.Extractor
import androidx.media3.extractor.ExtractorInput
import androidx.media3.extractor.ExtractorOutput
import androidx.media3.extractor.ExtractorsFactory
import androidx.media3.extractor.PositionHolder
import androidx.media3.extractor.SeekMap
import androidx.media3.extractor.SeekPoint
import androidx.media3.extractor.TrackOutput
import java.io.FileDescriptor
import java.nio.ByteBuffer

/** Cluster table of an MKV file: start time (us) and absolute byte position of every cluster. */
class MkvIndex(val timesUs: LongArray, val positions: LongArray, val durationUs: Long)

object MkvScanner {
    private const val ID_EBML = 0x1A45DFA3L
    private const val ID_SEGMENT = 0x18538067L
    private const val ID_INFO = 0x1549A966L
    private const val ID_CLUSTER = 0x1F43B675L
    private const val ID_TIMECODE = 0xE7L
    private const val ID_TIMESCALE = 0x2AD7B1L
    private const val ID_DURATION = 0x4489L

    private class H(val id: Long, val size: Long, val len: Int)

    private fun parse(b: ByteArray, off: Int, end: Int): H? {
        if (off >= end) return null
        val b0 = b[off].toInt() and 0xFF
        if (b0 == 0) return null
        val idLen = Integer.numberOfLeadingZeros(b0) - 24 + 1
        if (idLen > 4 || off + idLen >= end) return null
        var id = 0L
        for (i in 0 until idLen) id = (id shl 8) or (b[off + i].toLong() and 0xFF)
        val s0 = b[off + idLen].toInt() and 0xFF
        if (s0 == 0) return null
        val sLen = Integer.numberOfLeadingZeros(s0) - 24 + 1
        if (off + idLen + sLen > end) return null
        val mask = 0xFF shr sLen
        var v = (s0 and mask).toLong()
        var allOnes = v == mask.toLong()
        for (i in 1 until sLen) {
            val x = b[off + idLen + i].toLong() and 0xFF
            v = (v shl 8) or x
            if (x != 0xFFL) allOnes = false
        }
        return H(id, if (allOnes) -1L else v, idLen + sLen)
    }

    private fun uint(b: ByteArray, off: Int, len: Int): Long {
        var v = 0L
        for (i in 0 until len) v = (v shl 8) or (b[off + i].toLong() and 0xFF)
        return v
    }

    /** Why the last scan returned null (shown in a toast when we fall back to VLC). */
    @Volatile var lastError: String = ""

    /** Returns null if the file is not an MKV or cannot be indexed. */
    fun scan(ctx: Context, uri: Uri): MkvIndex? {
        lastError = ""
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
        if (pfd == null) { lastError = "file open nahi hui"; return null }
        pfd.use {
            val size = try { Os.fstat(it.fileDescriptor).st_size } catch (e: Exception) { it.statSize }
            return scanFd(it.fileDescriptor, size)
        }
    }

    /** Finds the next Cluster ID (1F 43 B6 75) at or after [from]; -1 if none. */
    private fun findNextCluster(fd: FileDescriptor, from: Long, fileSize: Long): Long {
        val chunk = ByteArray(65536 + 3)
        var p = from
        while (p < fileSize) {
            val n = try { Os.pread(fd, chunk, 0, chunk.size, p) } catch (e: Exception) { -1 }
            if (n < 4) return -1
            for (i in 0..n - 4) {
                if (chunk[i] == 0x1F.toByte() && chunk[i + 1] == 0x43.toByte() &&
                    chunk[i + 2] == 0xB6.toByte() && chunk[i + 3] == 0x75.toByte()
                ) return p + i
            }
            p += (n - 3).toLong()
        }
        return -1
    }

    private fun scanFd(fd: FileDescriptor, fileSize: Long): MkvIndex? {
        fun read(off: Long, b: ByteArray, len: Int): Int =
            try { Os.pread(fd, b, 0, len, off) } catch (e: Exception) { -1 }

        val buf = ByteArray(512)
        var n = read(0, buf, 16)
        if (n < 8) { lastError = "file padh nahi payi"; return null }
        val eh = parse(buf, 0, n)
        if (eh == null || eh.id != ID_EBML || eh.size < 0) { lastError = "MKV file nahi hai"; return null }
        var pos = eh.len + eh.size
        n = read(pos, buf, 16)
        if (n < 8) { lastError = "Segment nahi mila"; return null }
        val sh = parse(buf, 0, n)
        if (sh == null || sh.id != ID_SEGMENT) { lastError = "Segment nahi mila"; return null }
        pos += sh.len

        var scale = 1_000_000L
        var durationTicks = -1.0
        val tcs = ArrayList<Long>()
        val poss = ArrayList<Long>()
        var complete = false

        while (true) {
            if (pos >= fileSize - 1) { complete = true; break }
            n = read(pos, buf, buf.size)
            if (n <= 0) { lastError = "read fail @$pos"; break }
            val h = parse(buf, 0, n)
            if (h == null) {
                // Garbage / corrupt bytes: resync on the next cluster
                val nx = findNextCluster(fd, pos + 1, fileSize)
                if (nx < 0) {
                    complete = tcs.size >= 2
                    if (!complete) lastError = "header padh nahi paya @$pos"
                    break
                }
                pos = nx
                continue
            }
            if (h.id == ID_CLUSTER) {
                var o = h.len
                var found = -1L
                var guard = 0
                while (o < n && guard++ < 12) {
                    val c = parse(buf, o, n) ?: break
                    if (c.size < 0) break
                    if (c.id == ID_TIMECODE && c.size in 1..8 && o + c.len + c.size <= n) {
                        found = uint(buf, o + c.len, c.size.toInt())
                        break
                    }
                    val next = o.toLong() + c.len + c.size
                    if (next >= n) break
                    o = next.toInt()
                }
                if (found >= 0) {
                    tcs.add(found)
                    poss.add(pos)
                }
            } else if (h.id == ID_INFO && h.size in 1..4096) {
                val ib = ByteArray(h.size.toInt())
                val m = read(pos + h.len, ib, ib.size)
                var o = 0
                while (o < m) {
                    val c = parse(ib, o, m) ?: break
                    if (c.size < 0 || o + c.len + c.size > m) break
                    val ds = o + c.len
                    val sz = c.size.toInt()
                    if (c.id == ID_TIMESCALE && sz in 1..8) scale = uint(ib, ds, sz)
                    else if (c.id == ID_DURATION) {
                        val bb = ByteBuffer.wrap(ib, ds, sz)
                        durationTicks = when (sz) {
                            4 -> bb.float.toDouble()
                            8 -> bb.double
                            else -> -1.0
                        }
                    }
                    o = ds + sz
                }
            }
            if (h.size < 0) {
                if (h.id == ID_CLUSTER) {
                    // Unknown-size cluster: jump to the next cluster header
                    val nx = findNextCluster(fd, pos + h.len, fileSize)
                    if (nx < 0) { complete = true; break }
                    pos = nx
                    continue
                }
                lastError = "unknown-size element"
                break
            }
            pos += h.len + h.size
        }

        if (!complete) {
            if (lastError.isEmpty()) lastError = "scan poora nahi hua"
            return null
        }
        if (tcs.size < 2) { lastError = "clusters kam mile (${tcs.size})"; return null }
        if (scale <= 0L) { lastError = "timescale galat"; return null }

        // Keep only entries whose time does not go backwards (needed for binary search)
        val tl = ArrayList<Long>()
        val pl = ArrayList<Long>()
        var prev = Long.MIN_VALUE
        for (i in tcs.indices) {
            val t = tcs[i] * scale / 1000
            if (t >= prev) { tl.add(t); pl.add(poss[i]); prev = t }
        }
        if (tl.size < 2) { lastError = "cluster order galat"; return null }
        val times = LongArray(tl.size) { tl[it] }
        val positions = LongArray(pl.size) { pl[it] }
        val last = times.last()
        val dur = if (durationTicks > 0) (durationTicks * scale / 1000).toLong()
        else last + (last - times[times.size - 2]).coerceAtLeast(1_000_000L)
        return MkvIndex(times, positions, dur)
    }
}

class IndexSeekMap(private val idx: MkvIndex, private val durUs: Long) : SeekMap {
    override fun isSeekable(): Boolean = true
    override fun getDurationUs(): Long = durUs
    override fun getSeekPoints(timeUs: Long): SeekMap.SeekPoints {
        val t = idx.timesUs
        var lo = 0
        var hi = t.size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) ushr 1
            if (t[mid] <= timeUs) lo = mid else hi = mid - 1
        }
        return SeekMap.SeekPoints(SeekPoint(t[lo], idx.positions[lo]))
    }
}

/** Wraps an extractor; if it reports an unseekable stream, substitutes our cluster index. */
class IndexingExtractor(private val delegate: Extractor, private val idx: MkvIndex) : Extractor {
    override fun sniff(input: ExtractorInput): Boolean = delegate.sniff(input)

    override fun init(output: ExtractorOutput) {
        delegate.init(object : ExtractorOutput {
            override fun track(id: Int, type: Int): TrackOutput = output.track(id, type)
            override fun endTracks() = output.endTracks()
            override fun seekMap(seekMap: SeekMap) {
                if (seekMap.isSeekable) {
                    output.seekMap(seekMap)
                } else {
                    val d = seekMap.durationUs
                    output.seekMap(IndexSeekMap(idx, if (d > 0) d else idx.durationUs))
                }
            }
        })
    }

    override fun read(input: ExtractorInput, seekPosition: PositionHolder): Int =
        delegate.read(input, seekPosition)

    override fun seek(position: Long, timeUs: Long) = delegate.seek(position, timeUs)

    override fun release() = delegate.release()
}

/** DefaultExtractorsFactory is final in media3, so we wrap it instead of inheriting from it. */
class IndexedExtractorsFactory(
    private val idx: MkvIndex,
    private val base: DefaultExtractorsFactory
) : ExtractorsFactory {
    override fun createExtractors(): Array<Extractor> =
        base.createExtractors().map { IndexingExtractor(it, idx) as Extractor }.toTypedArray()

    override fun createExtractors(
        uri: Uri,
        responseHeaders: Map<String, List<String>>
    ): Array<Extractor> =
        base.createExtractors(uri, responseHeaders)
            .map { IndexingExtractor(it, idx) as Extractor }
            .toTypedArray()
}
