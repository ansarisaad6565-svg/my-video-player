package com.example.videoplayer

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri

data class Video(
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val size: Long,
    val bucketId: Long,
    val bucket: String
) {
    val ep: EpInfo? by lazy(LazyThreadSafetyMode.NONE) { NameParser.parseEpisode(name) }
}

data class EpInfo(val series: String, val season: Int, val episode: Int)

class SeriesGroup(val key: String, val name: String, val eps: List<Video>)

class FolderContent(val series: List<SeriesGroup>, val singles: List<Video>)

object NameParser {
    private val seasonEpisode = listOf(
        Regex("""(?i)^(.*?)[\s._\-\[(]*(?<![a-z])s(\d{1,2})[\s._-]*e(?:p)?[\s._-]*(\d{1,3})(?!\d)"""),
        Regex("""(?i)^(.*?)[\s._\-\[(]*season[\s._-]*(\d{1,2})[\s._\-,]*(?:episode|ep|e)[\s._-]*(\d{1,3})(?!\d)"""),
        Regex("""(?i)^(.*?)[\s._\-\[(]*(?<!\d)(\d{1,2})x(\d{1,3})(?!\d)""")
    )
    private val epOnly =
        Regex("""(?i)^(.*?)[\s._\-\[(]*(?<![a-z])(?:episode|ep|e)[\s._-]?(\d{1,3})(?!\d)""")
    private val anime =
        Regex("""^(?:\[[^\]]*][\s._]*)?(.+?)[\s._]*-[\s._]*(\d{1,3})(?:v\d)?(?=[\s._\[(]|$)""")
    private val junk = Regex(
        """(?i)[\s._\-(\[]+(2160p|1080p|720p|576p|480p|4k|uhd|bluray|blu-ray|brrip|bdrip|webrip|web-dl|webdl|hdrip|hdtv|dvdrip|x264|x265|h264|h265|hevc|10bit|remux|yify|rarbg)\b.*$"""
    )
    private val bracket = Regex("""\[[^\]]*]""")
    private val paren = Regex("""\([^)]*\)""")
    private val spaces = Regex("""\s+""")

    private fun stripExt(n: String) = n.substringBeforeLast('.')

    private fun cutJunk(s: String) = junk.replace(s, "")

    private fun tidy(raw: String, dropParens: Boolean): String {
        var s = raw.replace(bracket, " ")
        if (dropParens) s = s.replace(paren, " ")
        s = s.replace('.', ' ').replace('_', ' ')
        return s.replace(spaces, " ").trim(' ', '-')
    }

    fun key(s: String) = s.lowercase().filter { it.isLetterOrDigit() }

    fun parseEpisode(fileName: String): EpInfo? {
        val base = stripExt(fileName)
        for (r in seasonEpisode) {
            val m = r.find(base) ?: continue
            val season = m.groupValues[2].toIntOrNull() ?: continue
            val ep = m.groupValues[3].toIntOrNull() ?: continue
            return EpInfo(tidy(cutJunk(m.groupValues[1]), true), season, ep)
        }
        epOnly.find(base)?.let { m ->
            val ep = m.groupValues[2].toIntOrNull()
            if (ep != null) return EpInfo(tidy(cutJunk(m.groupValues[1]), true), 1, ep)
        }
        anime.find(base)?.let { m ->
            val ep = m.groupValues[2].toIntOrNull()
            if (ep != null) return EpInfo(tidy(cutJunk(m.groupValues[1]), true), 1, ep)
        }
        return null
    }

    /** Movie / single video title: file name without extension and without quality tags. */
    fun movieTitle(fileName: String): String {
        val t = tidy(cutJunk(stripExt(fileName)), false)
        return if (t.isBlank()) stripExt(fileName) else t
    }

    fun episodeTitle(seriesName: String, v: Video): String {
        val e = v.ep ?: return movieTitle(v.name)
        return "%s \u2022 S%02dE%02d".format(seriesName, e.season, e.episode)
    }

    /** Splits the videos of one folder into series (2+ episodes of the same show) and single videos. */
    fun group(vs: List<Video>, folderName: String): FolderContent {
        val byKey = LinkedHashMap<String, MutableList<Video>>()
        val names = HashMap<String, String>()
        val rest = ArrayList<Video>()
        for (v in vs) {
            val e = v.ep
            if (e == null) { rest.add(v); continue }
            val nm = if (e.series.isBlank()) folderName else e.series
            val k = key(nm).ifEmpty { "x" }
            byKey.getOrPut(k) { ArrayList() }.add(v)
            if (!names.containsKey(k)) names[k] = nm
        }
        val series = ArrayList<SeriesGroup>()
        for ((k, list) in byKey) {
            if (list.size >= 2) {
                val sorted = list.sortedWith(
                    compareBy<Video>({ it.ep?.season ?: 0 }, { it.ep?.episode ?: 0 }, { it.name })
                )
                series.add(SeriesGroup(k, names[k] ?: folderName, sorted))
            } else rest.addAll(list)
        }
        series.sortBy { it.name.lowercase() }
        return FolderContent(series, rest.sortedBy { it.name.lowercase() })
    }
}

/** Episode list handed from the library to the players (next / previous episode). */
object Playlist {
    const val URIS = "plist_uris"
    const val TITLES = "plist_titles"
    const val INDEX = "pindex"

    fun carry(to: Intent, from: Intent): Intent {
        from.getStringArrayListExtra(URIS)?.let { to.putStringArrayListExtra(URIS, it) }
        from.getStringArrayListExtra(TITLES)?.let { to.putStringArrayListExtra(TITLES, it) }
        to.putExtra(INDEX, from.getIntExtra(INDEX, 0))
        return to
    }

    fun has(cur: Intent, delta: Int): Boolean {
        val uris = cur.getStringArrayListExtra(URIS) ?: return false
        val titles = cur.getStringArrayListExtra(TITLES) ?: return false
        val idx = cur.getIntExtra(INDEX, 0) + delta
        return idx >= 0 && idx < uris.size && idx < titles.size
    }

    fun next(ctx: Context, cls: Class<*>, cur: Intent, delta: Int): Intent? {
        if (!has(cur, delta)) return null
        val uris = cur.getStringArrayListExtra(URIS) ?: return null
        val titles = cur.getStringArrayListExtra(TITLES) ?: return null
        val idx = cur.getIntExtra(INDEX, 0) + delta
        return Intent(ctx, cls)
            .putExtra("uri", uris[idx])
            .putExtra("title", titles[idx])
            .putStringArrayListExtra(URIS, uris)
            .putStringArrayListExtra(TITLES, titles)
            .putExtra(INDEX, idx)
    }
}

object AppTheme {
    val names = listOf("Dark", "AMOLED Black", "Ocean Blue", "Royal Purple", "Crimson")
    private val styles = listOf(
        R.style.Theme_VP, R.style.Theme_VP_Amoled, R.style.Theme_VP_Blue,
        R.style.Theme_VP_Purple, R.style.Theme_VP_Red
    )

    fun index(ctx: Context): Int =
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).getInt("theme", 0)
            .coerceIn(0, styles.size - 1)

    fun set(ctx: Context, i: Int) {
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
    }

    fun apply(a: Activity) = a.setTheme(styles[index(a)])
}

fun fmtDuration(ms: Long): String {
    val s = ms / 1000
    return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, s % 3600 / 60, s % 60)
    else "%d:%02d".format(s / 60, s % 60)
}
