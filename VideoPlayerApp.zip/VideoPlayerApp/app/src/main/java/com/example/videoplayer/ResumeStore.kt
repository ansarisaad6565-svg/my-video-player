package com.example.videoplayer

import android.content.Context
import android.net.Uri

/**
 * Remembers where each video was left.
 * Stored value: > 0 = position in ms, -1 = fully watched.
 */
object ResumeStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("resume", Context.MODE_PRIVATE)

    /** Position to resume from (0 when never watched or already finished). */
    fun get(ctx: Context, uri: Uri): Long =
        prefs(ctx).getLong(uri.toString(), 0L).coerceAtLeast(0L)

    fun clearAll(ctx: Context) { prefs(ctx).edit().clear().apply() }

    fun markDone(ctx: Context, uri: Uri) {
        prefs(ctx).edit().putLong(uri.toString(), -1L).apply()
    }

    /** Watched fraction 0..1 (1 = finished). */
    fun progress(ctx: Context, uri: Uri, durMs: Long): Float {
        val v = prefs(ctx).getLong(uri.toString(), 0L)
        return when {
            v < 0L -> 1f
            v == 0L || durMs <= 0L -> 0f
            else -> (v.toFloat() / durMs).coerceIn(0f, 1f)
        }
    }

    /** Saves [posMs]; marks the video as finished when it is nearly at the end. */
    fun save(ctx: Context, uri: Uri, posMs: Long, durMs: Long) {
        val key = uri.toString()
        val old = prefs(ctx).getLong(key, 0L)
        val e = prefs(ctx).edit()
        when {
            durMs > 0 && posMs > durMs - 10_000L -> e.putLong(key, -1L)
            posMs < 5_000L -> if (old > 0L) e.remove(key)   // keep the "finished" mark
            else -> e.putLong(key, posMs)
        }
        e.apply()
    }
}
