package com.example.videoplayer

import android.content.Context
import android.net.Uri

/** Remembers where each video was left, so playback can resume from there. */
object ResumeStore {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("resume", Context.MODE_PRIVATE)

    fun get(ctx: Context, uri: Uri): Long = prefs(ctx).getLong(uri.toString(), 0L)

    fun clearAll(ctx: Context) { prefs(ctx).edit().clear().apply() }

    /** Saves [posMs]; clears the entry when the video is at the very start or nearly finished. */
    fun save(ctx: Context, uri: Uri, posMs: Long, durMs: Long) {
        val e = prefs(ctx).edit()
        val key = uri.toString()
        if (posMs < 5_000L || (durMs > 0 && posMs > durMs - 10_000L)) e.remove(key)
        else e.putLong(key, posMs)
        e.apply()
    }
}
